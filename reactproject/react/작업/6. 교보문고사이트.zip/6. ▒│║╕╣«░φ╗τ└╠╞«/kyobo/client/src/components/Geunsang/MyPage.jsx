import React from "react";



export default function MyPage() {

    return (

        <>
            <div>마이페이지</div>
        </>

    )

}