import React from "react";


export default function DetailReviewBox(){


  return(
    <>
      <div className="detail-product__review_wrap--div">
        <p className="detail-product__review_title--p">
            <a href="#">리뷰&nbsp;
                <span className="detail-product__review_count--span">
                    (344)
                </span>
            </a>
        </p>
      </div>
    </>
  );
}