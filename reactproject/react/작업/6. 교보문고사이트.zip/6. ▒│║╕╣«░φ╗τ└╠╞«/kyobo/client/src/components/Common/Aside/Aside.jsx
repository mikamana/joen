import React from "react";
import "../../../css/Common/Aside/aside.css";


export default function Aside() {

    return (

        <>
            <aside>
                사이드
            </aside>
        </>

    )

};