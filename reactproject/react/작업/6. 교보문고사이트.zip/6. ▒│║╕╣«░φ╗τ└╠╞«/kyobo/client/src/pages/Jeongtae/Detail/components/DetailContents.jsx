import React from "react";
import "../../../../css/Jeongtae/Detail/detail.css";
import "../../../../css/Common/Mixin/common.css";
import "../../../../css/Common/Mixin/mixin.css";
import DetailProduct from "./DetailProduct";

export default function DetailContents() {

    return (

        <>
            <main className="detail" id="detail">
                <DetailProduct />
            </main>
        </>

    );

}