import React from "react";



export default function Admin() {

    return (

        <>
            <div>관리자페이지</div>
        </>

    )

}