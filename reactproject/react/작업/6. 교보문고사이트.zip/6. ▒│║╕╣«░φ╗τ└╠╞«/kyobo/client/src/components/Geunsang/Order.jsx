import React from "react";



export default function Order() {

    return (

        <>
            <div>주문페이지</div>
        </>

    )

}