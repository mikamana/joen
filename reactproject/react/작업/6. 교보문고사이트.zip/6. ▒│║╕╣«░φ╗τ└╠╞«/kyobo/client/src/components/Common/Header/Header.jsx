import React from "react";
import "../../../css/Common/Header/header.css";

export default function Header() {

    return (

        <>
            <header className="header_wrap">
                <h1>교보문고</h1>
            </header>
        </>

    )

};