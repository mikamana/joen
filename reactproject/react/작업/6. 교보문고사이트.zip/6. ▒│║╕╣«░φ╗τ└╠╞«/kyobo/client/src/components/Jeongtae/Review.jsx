import React from "react";
import Header from "../Common/Header/Header";
import Footer from "../Common/Footer/Footer";
import Aside from "../Common/Aside/Aside";


export default function Review() {


    return (

        <>
            <Header />
            <Aside />
            <Footer />
        </>

    );

}