import React from "react";



export default function Join() {

    return (

        <>
            <div>회원가입페이지</div>
        </>

    )

}