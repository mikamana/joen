import React from "react";
import "../../../css/Common/SubHeader/subheader.css";

export default function SubHeader() {

    return (

        <>
            <header class="subheader">
                <h1>교보문고</h1>
            </header>
        </>

    )

};