import React from "react";
import "../../../css/Common/Footer/footer.css";

export default function Footer() {

    return (

        <>
            <footer className="footer_wrap">
                푸터
            </footer>
        </>

    )

};