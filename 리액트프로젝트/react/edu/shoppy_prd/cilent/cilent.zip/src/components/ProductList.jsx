import React from "react";

export default function ProductList({children}){
  return(
    <div className="productlist">{children}</div>
  );
}